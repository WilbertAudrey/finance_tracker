part of 'expense_cubit.dart';

@immutable
sealed class ExpenseState {}

final class ExpenseInitial extends ExpenseState {}
