part of 'income_cubit.dart';

@immutable
sealed class IncomeState {}

final class IncomeInitial extends IncomeState {}
